# MacanOS v0.6 — multi-display development module

Working desktop C++17 / Qt 6 / QML simulator with three runtime modes:

- **INDEPENDENT:** separate Navigation/Media selection and persistent layout state per process.
- **UNIFIED:** two clipped viewports into one logical panorama, including a bezel gap and synchronized media visualization.
- **SHARED:** shared navigation/media focus with role-specific driver and passenger layouts.

Mode changes use one running backend and do not restart it. Shared destination proposals require driver approval. Shared media controls synchronize silent fixture playback state and volume. Process loss, output absence and stale backend connections fall back to INDEPENDENT. Recovered displays require an explicit mode selection to resume a coordinated session.

**Baseline limitation:** this repository previously contained only recreated v0.5 documentation (`cefde60`), not the original application source or recorded v0.5 commit `d6a19ad`. This is a new, independently tested integration module, not a verified upgrade of that missing application. It does not reproduce v0.5's live map, audio playback, trip SQLite database or exact interface. Its telemetry, route schematic, journey and silent media are visibly labelled simulator fixtures. No vehicle interface or factory controls are present.

## Build and run

Use Qt 6.7 or newer (tested: Debian 13, Qt 6.8.2, GCC 14.2), CMake 3.21+, Ninja and Python 3. On Debian 13:

```sh
sudo apt install build-essential cmake ninja-build qt6-base-dev qt6-declarative-dev \
  qml6-module-qtquick qml6-module-qtquick-window qml6-module-qtquick-layouts \
  qml6-module-qtqml-workerscript
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build --parallel 4
python3 scripts/run-simulator.py
```

This starts one loopback server and two independent windows. Click mode buttons in either window. Navigation/Media buttons select locally in INDEPENDENT and globally in the coordinated modes. Use the passenger's “Share city center” button and the driver's approval card. Media state controls are fixtures, with no audio output.

State is written to `.runtime/`: `modes.json`, separate role INIs, diagnostics and logs. Ctrl+C stops the launcher session. Closing one frontend keeps its peer and backend alive; closing both ends the session. See [installation and simulator controls](docs/INSTALL-v0.6.md).

Headless rendering:

```sh
QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software python3 scripts/run-simulator.py
```

## Verify

```sh
ctest --test-dir build --output-on-failure
python3 tests/test_processes.py --build build
```

`./scripts/check.sh` configures, builds and runs both suites. The process tests require local TCP sockets and launch actual Qt clients. They also regenerate screenshots. Test sizes are simulation inputs, not verified NaviRider specifications.

- [Architecture, protocol and integration boundary](docs/ARCHITECTURE-v0.6.md)
- [Android and NaviRider hardware compatibility report](docs/HARDWARE-COMPATIBILITY-v0.6.md)
- [Actual validation and limitations](docs/VALIDATION-v0.6.md)
- [Rendered screenshot gallery](docs/GALLERY-v0.6.html)
- [v0.5 reconstructed documentation](docs/MacanOS-v0.5-Reports/reports/MacanOS-v0.5-Recreated-Report.md)

The desktop tests do not establish Android, physical dual-display, touchscreen, audio, OBD or NaviRider compatibility. See [licensing](LICENSING.md). Development is on a local `macanos/v0.6` branch; nothing has been published or merged.
