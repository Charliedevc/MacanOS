# Licensing

[OCTAVE](https://github.com/RobDeGeorge/OCTAVE) identifies its software license as GNU GPL version 3 or later (GPL-3.0-or-later). The recovered report archive contains no OCTAVE application source or binaries. This note records upstream terms and does not assign a license to the report bundle.

When importing the original MacanOS source, identify the exact OCTAVE base revision and review per-file and third-party terms. Preserve upstream copyright and license notices, include the GPL text, and mark modified covered files with notices and relevant dates. When conveying covered binaries, provide their complete Corresponding Source by a method allowed under GPLv3 section 6, including applicable build and installation scripts. Review bundled assets and dependencies separately.

See the [GNU GPL v3, sections 4–6](https://www.gnu.org/licenses/gpl-3.0.html).

## New v0.6 module

The new C++, QML, tests, configuration and deployment scripts in this v0.6 module are provided under GPL-3.0-or-later; see [COPYING](COPYING). No OCTAVE source was imported in this module because its MacanOS baseline is unavailable. The graphics are original QML schematics and procedural shapes, with no proprietary Porsche assets or map tiles. They need no map-provider API key and do not implement a licensed live-map service. The prior documentation archive retains its existing provenance.

Qt is an external dependency; comply with the license applicable to the selected Qt distribution and modules when conveying a combined application. This source package does not redistribute the host's Qt libraries. Actual map tiles/styles, audio codecs, artwork and routing terms must be reviewed when the original v0.5 services are restored; this module does not establish their licensing.
